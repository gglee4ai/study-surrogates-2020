.First.lib <- function(lib, pkg)
{
  library.dynam("SparseEm", pkg, lib)
}
